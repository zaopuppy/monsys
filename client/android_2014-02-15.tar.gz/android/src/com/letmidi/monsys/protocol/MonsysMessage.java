package com.letmidi.monsys.protocol;

public interface MonsysMessage {

}
