package com.letmidi.monsys;

public class FgwInfo {
  public String name = "<name>";
  public String id = "<id>";

  @Override
  public String toString() {
    return "FgwInfo [name=" + name + ", id=" + id + "]";
  }

}