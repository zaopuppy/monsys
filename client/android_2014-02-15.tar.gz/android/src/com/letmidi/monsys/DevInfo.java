package com.letmidi.monsys;

public class DevInfo {
  public String name = "<dev-name>";
  public int addr = 0xFF;
  public int type = 0xFF;
}
