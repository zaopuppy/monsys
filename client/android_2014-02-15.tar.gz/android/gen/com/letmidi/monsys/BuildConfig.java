/** Automatically generated file. DO NOT MODIFY */
package com.letmidi.monsys;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}