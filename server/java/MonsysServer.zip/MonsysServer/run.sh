#!/bin/bash

CLASSPATH="bin:libs/netty-all-4.0.19.Final.jar:libs/protobuf-java-2.5.0.jar"
JAVA_OPTS="-Xms256m -Xmx2048m"

# check limitations
# launchctl limit
# change it
# launchctl limit maxfiles 400000 unlimited
# write to /etc/launchd.conf for permanent saving
# limit maxfiles 400000 unlimited

main()
{
    case "$1" in
        "server")
            java -classpath "$CLASSPATH" $JAVA_OPTS com/letsmidi/monsys/PushServer
            ;;
        "client")
            java -classpath "$CLASSPATH" $JAVA_OPTS com/letsmidi/monsys/PushClient
            ;;
        "gen")
            /Volumes/Data/source/google/protobuf-2.5.0/out/bin/protoc \
              --java_out=src --cpp_out=cpp push.proto
            cp cpp/push.pb.* ../..
            cp -r src/com/letsmidi/monsys/protocol/Push.java ../../../client/android/src/com/letsmidi/monsys/protocol/
            ;;
        *)
            echo "Bad arguments"
            ;;
    esac
}

cd $(dirname $0)
main "$@"

