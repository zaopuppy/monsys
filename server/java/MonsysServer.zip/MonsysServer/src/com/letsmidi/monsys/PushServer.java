package com.letsmidi.monsys;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.Delimiters;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;

public class PushServer {
  public static void main(String[] args) {
    PushServer push_server = new PushServer();
    push_server.start();
  }

  private static final int PUSH_PORT = 1984;
  private static final int CTRL_PORT = 1988;

  public void start() {
    ChannelFuture push_future = startPushServer();
    ChannelFuture ctrl_future = startCtrlServer();

    try {
      push_future.channel().closeFuture().sync();
      ctrl_future.channel().closeFuture().sync();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  public ChannelFuture startPushServer() {
    Logger.i("startPushServer()");

    ServerBootstrap b = new ServerBootstrap();
    NioEventLoopGroup boss = new NioEventLoopGroup();
    NioEventLoopGroup worker = new NioEventLoopGroup(1);

    try {
      b.group(boss, worker)
       .channel(NioServerSocketChannel.class)
       .handler(new LoggingHandler(LogLevel.DEBUG))
       .childHandler(new PushServerInitializer())
       .option(ChannelOption.SO_BACKLOG, 128)
       .childOption(ChannelOption.SO_KEEPALIVE, true);

      return b.bind(PUSH_PORT).sync();
      // future.channel().closeFuture().sync();
    } catch (InterruptedException e) {
      e.printStackTrace();
//    } finally {
//      worker.shutdownGracefully();
//      boss.shutdownGracefully();
//    }
    }

    return null;
  }

  public ChannelFuture startCtrlServer() {
    Logger.i("startCtrlServer()");

    ServerBootstrap b = new ServerBootstrap();
    NioEventLoopGroup boss = new NioEventLoopGroup();
    NioEventLoopGroup worker = new NioEventLoopGroup(1);

    try {
      b.group(boss, worker)
      .channel(NioServerSocketChannel.class)
      .handler(new LoggingHandler(LogLevel.DEBUG))
      .childHandler(new ChannelInitializer<SocketChannel>() {
        @Override
        protected void initChannel(SocketChannel ch) throws Exception {
          ch.pipeline().addLast(new DelimiterBasedFrameDecoder(1024, Delimiters.lineDelimiter()),
                                new StringDecoder(), new StringEncoder(),
                                new CtrlServerHandler());
        }
      })
      .option(ChannelOption.SO_BACKLOG, 16)
      .childOption(ChannelOption.SO_KEEPALIVE, true);

      return b.bind(CTRL_PORT).sync();
    } catch (InterruptedException e) {
      e.printStackTrace();
    }

    return null;
  }

}
