package com.letsmidi.monsys;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.protobuf.ProtobufDecoder;
import io.netty.handler.codec.protobuf.ProtobufEncoder;
import io.netty.handler.codec.protobuf.ProtobufVarint32FrameDecoder;
import io.netty.handler.codec.protobuf.ProtobufVarint32LengthFieldPrepender;

import com.letsmidi.monsys.protocol.Push.PushMsg;

public class PushClientInitializer extends ChannelInitializer<SocketChannel> {
  @Override
  protected void initChannel(SocketChannel ch) throws Exception {
    ch.pipeline().addLast(new ProtobufVarint32LengthFieldPrepender(),
                          new ProtobufVarint32FrameDecoder(),
                          new ProtobufEncoder(),
                          new ProtobufDecoder(PushMsg.getDefaultInstance()),
                          new PushClientHandler());
  }
}
