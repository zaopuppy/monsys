package com.letsmidi.monsys;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.letsmidi.monsys.protocol.Push.Login;
import com.letsmidi.monsys.protocol.Push.MsgType;
import com.letsmidi.monsys.protocol.Push.PushMsg;

public class PushClient {
  public static void main(String[] args) {
    String local_host = "127.0.0.1";
    if (args.length == 1) {
      local_host = args[0];
    }
    PushClient push_client = new PushClient(local_host);
    push_client.start();
  }

  private final String mLocalHost;
  // private int mLocalPort = -1;

  public PushClient(String host) {
    mLocalHost = host;
  }

  public void start() {
    Bootstrap bootstrap = new Bootstrap();
    NioEventLoopGroup worker = new NioEventLoopGroup(1);

    try {
      bootstrap.group(worker)
               .channel(NioSocketChannel.class)
               .handler(new PushClientInitializer())
               .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 60*1000)
               .option(ChannelOption.SO_KEEPALIVE, true)
               .bind(mLocalHost, 0);

      final int connection_count = 1;
      ChannelFuture[] futures = new ChannelFuture[connection_count];
      for (int i = 0; i < connection_count; ++i) {
        System.out.println(i);
        futures[i] = bootstrap.connect("127.0.0.1", 1983);
      }

      Channel ch = null;
      for (ChannelFuture f: futures) {
        ch = f.sync().channel();
      }

      System.out.println("done for " + connection_count + " connections");

      ChannelFuture last_future = null;
      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
      for (;;) {
        String line = reader.readLine().trim();
        System.out.println("input: [" + line + "]");
        if (line == null || line.equals("exit")) {
          System.out.println("exit");
          break;
        }

        if (line.length() <= 0) {
          continue;
        }

        // last_future = ch.writeAndFlush(line + Delimiters.lineDelimiter());
        last_future = sendMsg(ch, line);
      }

      ch.close().sync();
      // ch.closeFuture().sync();
      if (last_future != null) {
        last_future.sync();
      }
    } catch (InterruptedException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      worker.shutdownGracefully();
    }
  }

  private ChannelFuture sendMsg(Channel ch, String line) {
    System.out.println("sendMsg");
    PushMsg.Builder builder = PushMsg.newBuilder();
    builder.setVersion(1);
    builder.setType(MsgType.LOGIN);

    Login.Builder login_builder = Login.newBuilder();
    login_builder.setDeviceId(line);

    builder.setLogin(login_builder);
    return ch.writeAndFlush(builder.build());
  }

}
