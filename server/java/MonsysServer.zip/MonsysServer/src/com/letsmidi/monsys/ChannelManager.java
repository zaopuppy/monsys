package com.letsmidi.monsys;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.util.internal.PlatformDependent;

import java.util.concurrent.ConcurrentMap;

public class ChannelManager {
  // Singleton
  public static ChannelManager INSTANCE = new ChannelManager();

  public static class ClientInfo {
    public final Channel channel;
    public final String deviceId;

    public ClientInfo(String deviceId, Channel ch) {
      this.deviceId = deviceId;
      this.channel = ch;
    }
  }

  private class ClientInfoRemover implements ChannelFutureListener {
    private final String mDeviceId;
    public ClientInfoRemover(String devId) {
      mDeviceId = devId;
    }

    @Override
    public void operationComplete(ChannelFuture future) throws Exception {
      mClientMap.remove(mDeviceId);
    }
  }

  private final ConcurrentMap<String, ClientInfo> mClientMap = PlatformDependent.newConcurrentHashMap(1000);

  private ChannelManager() {
    // TODO
  }

  public boolean add(ClientInfo info) {
    // return mChannelGroup.add(ch);
    ClientInfo old = mClientMap.putIfAbsent(info.deviceId, info);
    if (old != null) {
      Logger.e("Duplicated client");
      return false;
    }

    // XXX: not good, new listener everything...
    info.channel.closeFuture().addListener(new ClientInfoRemover(info.deviceId));

    return true;
  }

  public ClientInfo find(String device_id) {
    return mClientMap.get(device_id);
  }
}

