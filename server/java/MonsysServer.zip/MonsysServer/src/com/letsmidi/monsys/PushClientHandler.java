package com.letsmidi.monsys;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import com.letsmidi.monsys.protocol.Push.Login;
import com.letsmidi.monsys.protocol.Push.MsgType;
import com.letsmidi.monsys.protocol.Push.PushMsg;

public class PushClientHandler extends SimpleChannelInboundHandler<PushMsg> {

  private ChannelHandlerContext mContext = null;

  @Override
  public void channelActive(ChannelHandlerContext ctx) throws Exception {
    // save context, so we can use it in timer-callback
    mContext = ctx;
//    mContext.executor().schedule(new Runnable() {
//      @Override
//      public void run() {
//        // System.out.println("PushClientHandler timeout: run()");
//
//        mContext.executor().schedule(this, 1, TimeUnit.SECONDS);
//
//        sendTestMsg(mContext.channel());
//      }
//    }, 1, TimeUnit.SECONDS);

    super.channelActive(ctx);
  }

  private void sendTestMsg(Channel channel) {
    PushMsg.Builder builder = PushMsg.newBuilder();
    builder.setVersion(1);
    builder.setType(MsgType.LOGIN);

    Login.Builder login_builder = Login.newBuilder();
    login_builder.setDeviceId("test-device-id");

    builder.setLogin(login_builder);

    channel.writeAndFlush(builder.build());
  }

  @Override
  protected void channelRead0(ChannelHandlerContext ctx, PushMsg msg) throws Exception {
    System.out.println("received: [" + msg.getType().name() + "]");
    System.out.println("received: [" + msg.getLogin().getDeviceId() + "]");
  }

  @Override
  public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
    cause.printStackTrace();

    super.exceptionCaught(ctx, cause);
  }

}
